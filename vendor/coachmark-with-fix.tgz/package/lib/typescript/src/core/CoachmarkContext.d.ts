import React from 'react';
import { useCoachmarkStore } from './store';
import type { CoachmarkTheme, Plugin, StorageAdapter } from './types';
export type CoachmarkContextValue = ReturnType<typeof useCoachmarkStore> & {
    theme: CoachmarkTheme;
    storage: StorageAdapter;
};
export declare const CoachmarkProvider: React.FC<{
    children: React.ReactNode;
    theme?: Partial<CoachmarkTheme>;
    storage?: StorageAdapter;
    plugins?: Plugin[];
}>;
/**
 * Hook to access the coachmark context
 * @throws Error if used outside of CoachmarkProvider
 */
export declare const useCoachmarkContext: () => CoachmarkContextValue;
//# sourceMappingURL=CoachmarkContext.d.ts.map