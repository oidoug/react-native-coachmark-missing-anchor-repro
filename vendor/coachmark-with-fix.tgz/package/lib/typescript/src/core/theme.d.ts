import type { CoachmarkTheme } from './types';
export declare const defaultTheme: CoachmarkTheme;
//# sourceMappingURL=theme.d.ts.map