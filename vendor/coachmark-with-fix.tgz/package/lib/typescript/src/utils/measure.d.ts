import type { Rect } from '../core/types';
/**
 * Measures the position and dimensions of a component relative to the window.
 *
 * @param ref - A reference to a React Native component that supports `measureInWindow` method
 * @returns A Promise that resolves to a `Rect` object containing x, y coordinates, width, and height
 *
 * @remarks
 * On Android, this function adjusts the Y coordinate by adding the StatusBar height.
 * This is necessary because `measureInWindow` excludes the StatusBar height on Android,
 * but Modal components include it in their positioning.
 *
 * @throws Will reject with an Error if the ref is invalid or doesn't have the `measureInWindow` method
 *
 * @example
 * ```typescript
 * const viewRef = useRef(null);
 * const rect = await measureInWindowByRef(viewRef.current);
 * console.log(rect); // { x: 0, y: 100, width: 200, height: 50 }
 * ```
 */
export declare function measureInWindowByRef(ref: any): Promise<Rect>;
//# sourceMappingURL=measure.d.ts.map