import type { Tour, TourStep } from '../core/types';
export declare function resolveNextOnBackdropPress(step?: TourStep, tour?: Tour | null): boolean;
//# sourceMappingURL=resolveNextOnBackdropPress.d.ts.map