import type { SharedValue } from 'react-native-reanimated';
import type { TourStep } from '../core/types';
type AnchorGetter = (id: string) => any;
type UseTourMeasurementParams = {
    activeStep: TourStep | undefined;
    index: number;
    tourKey: string | undefined;
    getAnchor: AnchorGetter;
    setMeasured: (id: string, rect: any) => void;
    next: () => void;
    onAnchorMissing?: () => void;
    reduceMotion: boolean;
    durationMs: number;
    holeX: SharedValue<number>;
    holeY: SharedValue<number>;
    holeWidth: SharedValue<number>;
    holeHeight: SharedValue<number>;
};
/**
 * Custom hook that handles measurement and positioning of tour steps/coachmarks.
 *
 * This hook manages the lifecycle of measuring target elements, auto-scrolling to them if needed,
 * and animating the highlight hole to focus on the target. It runs whenever the active step changes
 * or window dimensions update.
 *
 * @param activeStep - The current active step in the tour, or null if no step is active
 * @param index - The index of the current step in the tour sequence
 * @param tourKey - Unique identifier for the tour instance
 * @param getAnchor - Function to retrieve an anchor element by its ID
 * @param setMeasured - Callback to store measured dimensions for a step
 * @param next - Function to proceed to the next step in the tour
 * @param onAnchorMissing - Called when a step's anchor can't be found and the tour has nothing on screen yet
 * @param reduceMotion - Whether to disable animations for accessibility
 * @param durationMs - Duration in milliseconds for hole animations
 * @param holeX - Reanimated shared value for the x-coordinate of the highlight hole
 * @param holeY - Reanimated shared value for the y-coordinate of the highlight hole
 * @param holeWidth - Reanimated shared value for the width of the highlight hole
 * @param holeHeight - Reanimated shared value for the height of the highlight hole
 *
 * @returns Object containing the measured target rectangle, hole shape configuration, hole radius, whether the step's anchor is mounted, and a remeasure function
 *
 * @example
 * ```typescript
 * const { targetRect, holeShape, holeRadius, remeasure } = useTourMeasurement({
 *   activeStep: currentStep,
 *   index: 0,
 *   tourKey: 'onboarding-tour',
 *   getAnchor: (id) => anchors.get(id),
 *   setMeasured: (id, rect) => measurements.set(id, rect),
 *   next: goToNextStep,
 *   reduceMotion: false,
 *   durationMs: 300,
 *   holeX: holeXValue,
 *   holeY: holeYValue,
 *   holeWidth: holeWidthValue,
 *   holeHeight: holeHeightValue,
 * });
 * ```
 */
export declare function useTourMeasurement({ activeStep, index, tourKey, getAnchor, setMeasured, next, onAnchorMissing, reduceMotion, durationMs, holeX, holeY, holeWidth, holeHeight, }: UseTourMeasurementParams): {
    hasAnchor: boolean;
    remeasure: () => Promise<void>;
    targetRect: {
        x: number;
        y: number;
        width: number;
        height: number;
    } | null;
    holeShape: "rect" | "circle" | "pill";
    holeRadius: number;
};
export {};
//# sourceMappingURL=useTourMeasurement.d.ts.map