import React from 'react';
import type { SharedValue } from 'react-native-reanimated';
import type { Rect, SpotlightShape } from '../core/types';
export type Hole = {
    rect: Rect;
    shape: SpotlightShape;
    radius?: number;
};
export type AnimatedHole = {
    x: SharedValue<number>;
    y: SharedValue<number>;
    width: SharedValue<number>;
    height: SharedValue<number>;
    shape: SpotlightShape;
    radius?: number;
};
/**
 * Static Mask (no animation) - for compatibility
 */
export declare const Mask: React.FC<{
    width: number;
    height: number;
    holes: Hole[];
    backdropColor: string;
    backdropOpacity: number;
}>;
/**
 * Animated Mask - smooth hole transitions with Reanimated
 */
export declare const AnimatedMask: React.FC<{
    width: number;
    height: number;
    holes: AnimatedHole[];
    backdropColor: string;
    backdropOpacity: number;
}>;
//# sourceMappingURL=Mask.d.ts.map