import React, { Component } from 'react';
import type { ReactNode } from 'react';
type ErrorBoundaryProps = {
    children: ReactNode;
    onError?: (error: Error, errorInfo: React.ErrorInfo) => void;
    onReset?: () => void;
    fallback?: (error: Error, resetError: () => void) => ReactNode;
};
type ErrorBoundaryState = {
    hasError: boolean;
    error: Error | null;
};
/**
 * Error Boundary component for catching errors in custom tooltips
 * Prevents the entire app from crashing when a custom tooltip renderer fails
 */
export declare class CoachmarkErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
    constructor(props: ErrorBoundaryProps);
    static getDerivedStateFromError(error: Error): ErrorBoundaryState;
    componentDidCatch(error: Error, errorInfo: React.ErrorInfo): void;
    resetError: () => void;
    render(): string | number | bigint | boolean | Iterable<React.ReactNode> | Promise<string | number | bigint | boolean | React.ReactPortal | React.ReactElement<unknown, string | React.JSXElementConstructor<any>> | Iterable<React.ReactNode> | null | undefined> | import("react/jsx-runtime").JSX.Element | null | undefined;
}
export {};
//# sourceMappingURL=CoachmarkErrorBoundary.d.ts.map