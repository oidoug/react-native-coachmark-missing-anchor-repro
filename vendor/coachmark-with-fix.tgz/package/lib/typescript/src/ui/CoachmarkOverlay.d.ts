import React from 'react';
/**
 * Main overlay component for displaying coachmarks
 * Optimized with React.memo and custom hooks to reduce re-renders
 */
export declare const CoachmarkOverlay: React.FC;
//# sourceMappingURL=CoachmarkOverlay.d.ts.map