import React from 'react';
import { type ViewProps } from 'react-native';
import type { SpotlightShape } from '../core/types';
export declare const CoachmarkAnchor: React.FC<ViewProps & {
    id: string;
    shape?: SpotlightShape;
    padding?: number;
    radius?: number;
    scrollRef?: React.RefObject<any>;
    children?: React.ReactNode;
}>;
//# sourceMappingURL=CoachmarkAnchor.d.ts.map